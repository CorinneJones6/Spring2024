var searchData=
[
  ['var_0',['Var',['../class_var.html#aab4916dada326e1183f06bb582ba0488',1,'Var']]]
];
